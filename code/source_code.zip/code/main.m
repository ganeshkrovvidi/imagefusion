close all;
clear;
clc;
%% Read Images

% the size of images must be equal

[file, pathname] = uigetfile('*.jpg','Load Image 1 ');cd(pathname);
im1=imread(file);
[file, pathname] = uigetfile('*.jpg','Load Image 2 ');cd(pathname);
im2=imread(file);

dwtfusion(im1,im2);
dctVarFusion(im1, im2);

close all;
clear;
clc;
%% Read Images

[file, pathname] = uigetfile('*.jpg','Load Image 1 ');cd(pathname);
im1=imread(file);
[file, pathname] = uigetfile('*.jpg','Load Image 2 ');cd(pathname);
im2=imread(file);
subplot(2,2,1), imshow(im1), title('Source image 1');
subplot(2,2,2), imshow(im2), title('Source image 2');
dwtfusion(im1,im2);
dctVarFusion(im1, im2);

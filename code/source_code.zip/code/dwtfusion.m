function im3 = dwtfusion(im1, im2)



%%   Wavelet Transform 


[a1,b1,c1,d1]=dwt2(im1,'db2');
[a2,b2,c2,d2]=dwt2(im2,'db2');

[k1,k2]=size(a1);

%% Fusion Rules

%% Average Rule

for i=1:k1
    for j=1:k2
        a3(i,j)=(a1(i,j)+a2(i,j))/2;
   end
end

%% Max Rule


for i=1:k1
    for j=1:k2
        b3(i,j)=max(b1(i,j),b2(i,j));
        c3(i,j)=max(c1(i,j),c2(i,j));
        d3(i,j)=max(d1(i,j),d2(i,j));
    end
end





%% Inverse Wavelet Transform 

im3=idwt2(a3,b3,c3,d3,'db2');

subplot(2,2,3), imshow(im3,[]), title('Fused Image using DWT');


%% Performance Criteria

CR1=corr2(im1,im3);
CR2=corr2(im2,im3);
S1=snrr(double(im1),double(im3));
S2=snrr(double(im2),double(im3));


fprintf('Correlation between first image and dwt fused image =%f \n\n',CR1);
fprintf('Correlation between second image and dwt fused image =%f \n\n',CR2);
fprintf('SNR between first image and dwt fused image =%4.2f db\n\n',S1);
fprintf('SNR between second image and dwt fused image =%4.2f db \n\n',S2);


